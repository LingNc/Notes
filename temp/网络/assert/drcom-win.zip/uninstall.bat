@echo off
REM Uninstall Drcom service installed via NSSM
setlocal
set WORKDIR=%~dp0
set SERVICE_NAME=Drcom
set NSSM_EXE=%WORKDIR%nssm.exe

whoami /groups | findstr /i "S-1-5-32-544" >nul
if not %errorlevel%==0 (
  echo [ERROR] Please run this script as Administrator.
  pause
  exit /b 1
)

sc query %SERVICE_NAME% >nul 2>&1
if %errorlevel%==0 (
  echo Stopping service %SERVICE_NAME%...
  sc stop %SERVICE_NAME% >nul 2>&1
  timeout /t 3 >nul
  if exist "%NSSM_EXE%" (
    "%NSSM_EXE%" remove %SERVICE_NAME% confirm
  ) else (
    sc delete %SERVICE_NAME%
  )
) else (
  echo Service %SERVICE_NAME% does not exist.
)
endlocal
