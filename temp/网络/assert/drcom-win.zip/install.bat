﻿@echo off
REM Drcom Windows 安装脚本：注册为 Windows 服务并开机自启
REM 依赖：nssm.exe 与 dogcom.exe 均需位于当前目录（drcom-win）
REM 配置：drcom.conf；日志：drcom.log

setlocal enabledelayedexpansion
set WORKDIR=%~dp0
REM ==== 关键修复：移除路径末尾的反斜杠，防止 \" 转义问题 ====
if "%WORKDIR:~-1%"=="\" set WORKDIR=%WORKDIR:~0,-1%
REM ================================================================

set SERVICE_NAME=Drcom
set DOGCOM_EXE=%WORKDIR%\dogcom.exe
set NSSM_EXE=%WORKDIR%\nssm.exe
set CONF_FILE=%WORKDIR%\drcom.conf
set LOG_FILE=%WORKDIR%\drcom.log
set ERROR_LOG_FILE=%WORKDIR%\drcom_error.log

REM 以管理员运行检查（尝试写注册表/服务会失败，如非管理员）
whoami /groups | findstr /i "S-1-5-32-544" >nul
if not %errorlevel%==0 (
  echo [ERROR] 请使用管理员权限运行此脚本。
  pause
  exit /b 1
)

if not exist "%DOGCOM_EXE%" (
  echo [ERROR] 未找到 dogcom.exe：%DOGCOM_EXE%
  echo 请将已编译的 Windows 版本 dogcom.exe 放入 drcom-win 目录。
  exit /b 1
)
if not exist "%NSSM_EXE%" (
  echo [ERROR] 未找到 nssm.exe：%NSSM_EXE%
  echo 说明：普通可执行程序无法直接作为 Windows 服務运行，建议使用 NSSM 包装。
  echo 请下载 NSSM 并放入当前目录，例如：https://nssm.cc/download
  exit /b 1
)
if not exist "%CONF_FILE%" (
  echo [ERROR] 未找到配置文件：%CONF_FILE%
  exit /b 1
)

REM 创建日志文件（如不存在）
if not exist "%LOG_FILE%" (
  type nul > "%LOG_FILE%"
)

REM 如果服务已存在，先停止并删除以便重新安装
sc query %SERVICE_NAME% >nul 2>&1
if %errorlevel%==0 (
  echo [INFO] 检测到服务已存在：%SERVICE_NAME% ，正在停止并移除...
  sc stop %SERVICE_NAME% >nul 2>&1
  timeout /t 3 >nul
  "%NSSM_EXE%" remove %SERVICE_NAME% confirm >nul 2>&1
)

REM 使用 NSSM 安装服务
"%NSSM_EXE%" install %SERVICE_NAME% %DOGCOM_EXE% -m dhcp -c %CONF_FILE% -v
if not %errorlevel%==0 (
  echo [ERROR] NSSM 安装服务失败。
  exit /b 1
)

REM 服务参数：工作目录与自动重启策略
REM 1. 强制指定工作目录（关键：服务必须在此目录下才能找到配置文件）
"%NSSM_EXE%" set %SERVICE_NAME% AppDirectory "%WORKDIR%"
REM 2. 设置启动类型为自动
"%NSSM_EXE%" set %SERVICE_NAME% Start SERVICE_AUTO_START
REM 3. 重定向stdin防止阻塞
"%NSSM_EXE%" set %SERVICE_NAME% AppStdin NUL
REM 4. 分别重定向标准输出和错误输出到不同日志文件
"%NSSM_EXE%" set %SERVICE_NAME% AppStdout "%LOG_FILE%"
"%NSSM_EXE%" set %SERVICE_NAME% AppStderr "%ERROR_LOG_FILE%"
"%NSSM_EXE%" set %SERVICE_NAME% AppStopMethodSkip 6
"%NSSM_EXE%" set %SERVICE_NAME% AppRestartDelay 5000
"%NSSM_EXE%" set %SERVICE_NAME% AppThrottle 1500
"%NSSM_EXE%" set %SERVICE_NAME% AppExit Default Restart

REM 启动服务
sc start %SERVICE_NAME%
if %errorlevel%==0 (
  echo =========================================
  echo 安装成功：服務 %SERVICE_NAME% 已启动并设置为开机自启。
  echo 工作目录：%WORKDIR%
  echo 日志文件：%LOG_FILE%
  echo 错误日志：%ERROR_LOG_FILE%
  echo 查看状态：sc query %SERVICE_NAME%
  echo 停止服務：sc stop %SERVICE_NAME%
  echo 删除服務：nssm remove %SERVICE_NAME% confirm
  echo =========================================
) else (
  echo [WARN] 已安装但启动可能失败，请检查日志：%LOG_FILE%
  sc query %SERVICE_NAME%
)

endlocal
