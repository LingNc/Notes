@echo off
REM Drcom Windows installer (English): register as a Windows service and auto-start
REM Dependencies: nssm.exe and dogcom.exe must be in this directory (drcom-win)
REM Config: drcom.conf; Log: drcom.log

setlocal enabledelayedexpansion
set WORKDIR=%~dp0
REM ==== Critical fix: Remove trailing backslash to prevent \" escape issue ====
if "%WORKDIR:~-1%"=="\" set WORKDIR=%WORKDIR:~0,-1%
REM ============================================================================

set SERVICE_NAME=Drcom
set DOGCOM_EXE=%WORKDIR%\dogcom.exe
set NSSM_EXE=%WORKDIR%\nssm.exe
set CONF_FILE=%WORKDIR%\drcom.conf
set LOG_FILE=%WORKDIR%\drcom.log
set ERROR_LOG_FILE=%WORKDIR%\drcom_error.log

REM Admin check: must run elevated
whoami /groups | findstr /i "S-1-5-32-544" >nul
if not %errorlevel%==0 (
  echo [ERROR] Please run this script as Administrator.
  pause
  exit /b 1
)

if not exist "%DOGCOM_EXE%" (
  echo [ERROR] dogcom.exe not found: %DOGCOM_EXE%
  echo Place the compiled Windows dogcom.exe in the drcom-win directory.
  exit /b 1
)
if not exist "%NSSM_EXE%" (
  echo [ERROR] nssm.exe not found: %NSSM_EXE%
  echo Note: Console apps cannot directly run as Windows services. Use NSSM to wrap them.
  echo Download NSSM and place it here, e.g. https://nssm.cc/download
  exit /b 1
)
if not exist "%CONF_FILE%" (
  echo [ERROR] Config file not found: %CONF_FILE%
  exit /b 1
)

REM Create log file if missing
if not exist "%LOG_FILE%" (
  type nul > "%LOG_FILE%"
)

REM If service exists, stop and remove it to allow clean reinstall
sc query %SERVICE_NAME% >nul 2>&1
if %errorlevel%==0 (
  echo [INFO] Service %SERVICE_NAME% already exists. Attempting to stop and remove...
  sc stop %SERVICE_NAME% >nul 2>&1
  timeout /t 3 >nul
  "%NSSM_EXE%" remove %SERVICE_NAME% confirm >nul 2>&1
)

REM Install service via NSSM
"%NSSM_EXE%" install %SERVICE_NAME% %DOGCOM_EXE% -m dhcp -c %CONF_FILE% -v
if not %errorlevel%==0 (
  echo [ERROR] NSSM failed to install the service.
  exit /b 1
)

REM Configure service properties
REM 1. Set working directory first (critical for service to find config file)
"%NSSM_EXE%" set %SERVICE_NAME% AppDirectory "%WORKDIR%"
REM 2. Set startup type
"%NSSM_EXE%" set %SERVICE_NAME% Start SERVICE_AUTO_START
REM 3. Redirect stdin to prevent blocking
"%NSSM_EXE%" set %SERVICE_NAME% AppStdin NUL
REM 4. Redirect stdout and stderr to separate log files
"%NSSM_EXE%" set %SERVICE_NAME% AppStdout "%LOG_FILE%"
"%NSSM_EXE%" set %SERVICE_NAME% AppStderr "%ERROR_LOG_FILE%"
"%NSSM_EXE%" set %SERVICE_NAME% AppStopMethodSkip 6
"%NSSM_EXE%" set %SERVICE_NAME% AppRestartDelay 5000
"%NSSM_EXE%" set %SERVICE_NAME% AppThrottle 1500
"%NSSM_EXE%" set %SERVICE_NAME% AppExit Default Restart

REM Start service
sc start %SERVICE_NAME%
if %errorlevel%==0 (
  echo =========================================
  echo Installed: service %SERVICE_NAME% started and set to auto-start.
  echo Workdir: %WORKDIR%
  echo Log file: %LOG_FILE%
  echo Error log: %ERROR_LOG_FILE%
  echo Check status: sc query %SERVICE_NAME%
  echo Stop service: sc stop %SERVICE_NAME%
  echo Remove service: nssm remove %SERVICE_NAME% confirm
  echo =========================================
) else (
  echo [WARN] Service installed but may have failed to start. Check log: %LOG_FILE%
  sc query %SERVICE_NAME%
)

endlocal
