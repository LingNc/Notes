#!/bin/bash

# drcom Linux 安装脚本：注册为 systemd 服务并开机自启
# 目录结构要求：
# - 同目录下存在可执行文件: dogcom
# - 同目录下存在配置文件: drcom.conf
# - 日志写入: drcom.log（自动创建或追加）

set -euo pipefail
SERVICE_NAME="drcom"
WORK_DIR=$(cd "$(dirname "$0")"; pwd)
DOGCOM_BIN="$WORK_DIR/dogcom"
CONF_FILE="$WORK_DIR/drcom.conf"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

# 1) 权限检查
if [ "${EUID}" -ne 0 ]; then
  echo -e "${RED}请使用 root 权限运行本脚本: sudo ./install.sh${NC}"
  exit 1
fi

# 2) 文件检查（只检查存在性，脚本会自动赋予执行权限）
if [ ! -f "$DOGCOM_BIN" ]; then
  echo -e "${RED}错误: 未找到文件: $DOGCOM_BIN${NC}"
  echo "请确保 dogcom 文件在当前目录下。"
  exit 1
fi
if [ ! -f "$CONF_FILE" ]; then
  echo -e "${RED}未找到配置文件: $CONF_FILE${NC}"
  exit 1
fi

# 3) 赋予 dogcom 执行权限
chmod +x "$DOGCOM_BIN" || {
  echo -e "${RED}赋予执行权限失败：$DOGCOM_BIN${NC}"
  exit 1
}

# 5) 写入 systemd 服务文件（Type=forking，去除 -l，日志走 journal）
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Drcom Client (dogcom) Service
After=network-online.target
Wants=network-online.target

[Service]
# Run in foreground: use simple so systemd treats the process as the main process
Type=simple
WorkingDirectory=${WORK_DIR}
# ExecStart: do not use -l logfile; let systemd/journal capture stdout/stderr
ExecStart=${DOGCOM_BIN} -m dhcp -c ${CONF_FILE}
Restart=always
RestartSec=5
# Direct log messages to the journal
StandardOutput=journal
StandardError=journal
# TimeoutStartSec removed: dogcom is run in foreground (Type=simple)
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

# 6) 重新加载与启用服务
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

# 7) 状态输出
sleep 2
if systemctl is-active --quiet "$SERVICE_NAME"; then
  echo -e "${GREEN}=========================================${NC}"
  echo -e "${GREEN} 安装成功：服务 drcom 已运行并设置为开机自启。${NC}"
  echo -e "${GREEN} 日志将写入 systemd journal (journalctl -u drcom)${NC}"
  echo -e "${GREEN}=========================================${NC}"
  echo "查看状态: systemctl status ${SERVICE_NAME}"
  echo "查看日志: journalctl -u ${SERVICE_NAME} -f"
else
  echo -e "${RED}服务启动失败，请查看日志与配置。${NC}"
  journalctl -u "$SERVICE_NAME" --no-pager -n 50 || true
fi
