#!/bin/bash

# drcom Linux 卸载脚本：停止并彻底移除 systemd 服务（修正版）

# NOTE: 不使用 set -e 避免中间某个命令失败导致脚本意外退出
set -u
SERVICE_NAME="drcom"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
DOGCOM_NAME="dogcom"

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

# 1) 权限检查
if [ "${EUID}" -ne 0 ]; then
  echo -e "${RED}请使用 root 权限运行本脚本: sudo ./uninstall.sh${NC}"
  exit 1
fi

echo "准备卸载服务：${SERVICE_NAME} ..."

# 2) 停止并禁用服务（即使失败也继续执行）
echo "正在停止服务..."
systemctl stop "${SERVICE_NAME}" 2>/dev/null || true
echo "正在禁用开机自启..."
systemctl disable "${SERVICE_NAME}" 2>/dev/null || true

# 3) 强杀残留进程
if pgrep -x "${DOGCOM_NAME}" >/dev/null 2>&1; then
  echo "检测到残留进程 ${DOGCOM_NAME}，正在强制结束..."
  pkill -9 -x "${DOGCOM_NAME}" 2>/dev/null || true
fi

# 4) 删除服务文件并刷新 systemd
if [ -f "${SERVICE_FILE}" ]; then
  echo "正在删除服务文件: ${SERVICE_FILE}"
  rm -f "${SERVICE_FILE}"

  echo "正在刷新 systemd 配置..."
  systemctl daemon-reload
  systemctl reset-failed 2>/dev/null || true

  echo -e "${GREEN}=========================================${NC}"
  echo -e "${GREEN}卸载成功：服务已彻底移除。${NC}"
  echo -e "${GREEN}=========================================${NC}"
else
  # 即便文件不存在，也确保 systemd 已刷新并停止了服务
  echo "服务文件 ${SERVICE_FILE} 已不存在。继续清理流程..."
  systemctl daemon-reload
  systemctl reset-failed 2>/dev/null || true
  echo -e "${GREEN}清理完成。${NC}"
fi
