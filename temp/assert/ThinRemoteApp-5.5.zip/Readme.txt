﻿ThinRemoteApp 是一款轻量化的应用虚拟化软件，将服务器端上安装的程序比如 Office、PDF、AutoCAD、Photoshop、3DMax、ERP等任意软件发布分发到客户端的电脑上运行，实现远程接入，远程办公或居家办公。
更多信息请访问ThinRemoteApp 软件官方网站 https://www.remoteapp.cn

如Thin RemoteApp的功能无法满足业务需求，可了解另一款应用虚拟化和桌面虚拟化商业解决方案，https://www.parallelsras.com。

ThinRemoteApp 功能特性
创建和管理 RemoteAPP 远程应用
创建和管理远程桌面
可快速生成.rdp 配置文件
可生成.msi 程序包(服务端需安装 WiX Toolset)
RDP文件签名
支持设置RD远程网关，实现SSL单端口传输
设备和资源重定向配置
可以配置超时时间、修改应用图标等
支持关联文件类型，使用远程应用打开文件
备份所有发布的 RemoteApp 程序

服务端运行环境要求
Windows 7/8/8.1/10/11
Windows Server 2008/2008R2
Windows Server 2012/2012R2
Windows Server 2016/2019/2022/2025
.Net Framework 4
可运行net472-web-installer.exe，在线安装.Net Framework 4.7.2


客户端操作系统平台
Windows XP/7/8/10/11
macOS 需安装Microsoft Remote Desktop

更新日志
v5.5.0（2023.04.17 ）
----------------------
- 新：RDP 文件签名
- 新：添加发布“远程桌面”
- 新：RemoteApp注册表备份
- 新：主机选项增加了设备和资源管理。剪贴板、COM端口、磁盘驱动器、打印机重定向设置。
- 新：增加主机状态页面，显示服务器硬件信息、操作系统版本、远程桌面状态及端口、系统启动时间。
- 新：远程服务器地址支持IPv6
- 修复：将RDP文件生成msi安装包时导致文件被锁的问题


v5.5.3（2023.11.08 ）
----------------------
- 新：复制“已经发布的程序或桌面”提高发布程序的效率
- 新：已发布远程桌面的注册表备份


 v5.5.4（2025.03.03）
----------------------
- 新：增加服务器端的 mstsc.exe是否存在的判断。Win11 23H2或更新的版本允许用户卸载mstsc.exe（mstsc.exe  /uninstall），参考：https://learn.microsoft.com/zh-cn/windows-server/remote/remote-desktop-services/clients/uninstall-remote-desktop-connection
- 优化：在Windows 11 23H2/24H2，Windows Server 2025的兼容问题
- 优化：发布程序数量多，导致应用列表加载慢的问题




