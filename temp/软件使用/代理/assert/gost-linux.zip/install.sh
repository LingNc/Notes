#!/bin/bash

# ================= 配置区域 =================
SERVICE_NAME="gost"
# 获取当前脚本所在的绝对路径
WORK_DIR=$(cd "$(dirname "$0")"; pwd)
GOST_BIN="$WORK_DIR/gost"
CONFIG_FILE="$WORK_DIR/config.yaml"
# ===========================================

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 1. 检查 Root 权限
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}错误: 请使用 root 权限运行此脚本 (sudo ./install.sh)${NC}"
  exit 1
fi

# 2. 检查文件是否存在
if [ ! -f "$GOST_BIN" ]; then
  echo -e "${RED}错误: 未找到 gost 文件！请确保它在当前目录下。${NC}"
  echo "路径检查: $GOST_BIN"
  exit 1
fi

if [ ! -f "$CONFIG_FILE" ]; then
  echo -e "${RED}错误: 未找到 config.yaml 文件！${NC}"
  exit 1
fi

# 3. 赋予执行权限
chmod +x "$GOST_BIN"
echo -e "已赋予 gost 执行权限..."

# 提取并打印 config.yaml 中 SS 和 SOCKS5 的账号密码
parse_and_show_creds() {
    echo -e "${GREEN}=========================================${NC}"
    echo -e "${GREEN} 配置信息摘要${NC}"
    echo -e "${GREEN}=========================================${NC}"

    # 定义搜索范围行数，防止漏掉靠后的配置
    local RANGE=15

    # ---------------- SS 配置提取 ----------------
    # 提取加密方式 (username 字段)
    local ss_method=$(grep -A $RANGE "name: ss-tcp" "$CONFIG_FILE" | grep "username:" | head -1 | awk -F'username:' '{print $2}' | sed 's/#.*//' | awk '{print $1}' | tr -d ' "')

    # 提取密码 (password 字段)
    local ss_password=$(grep -A $RANGE "name: ss-tcp" "$CONFIG_FILE" | grep "password:" | head -1 | awk -F'password:' '{print $2}' | sed 's/#.*//' | awk '{print $1}' | tr -d ' "')

    # 提取端口
    local ss_port=$(grep -A 2 "name: ss-tcp" "$CONFIG_FILE" | grep "addr:" | head -1 | awk -F':' '{print $NF}' | tr -d ' ')

    # ---------------- SOCKS5 配置提取 ----------------
    # 提取用户名
    local socks5_user=$(grep -A $RANGE "name: socks5-service" "$CONFIG_FILE" | grep "username:" | head -1 | awk -F'username:' '{print $2}' | sed 's/#.*//' | awk '{print $1}' | tr -d ' "')

    # 提取密码
    local socks5_password=$(grep -A $RANGE "name: socks5-service" "$CONFIG_FILE" | grep "password:" | head -1 | awk -F'password:' '{print $2}' | sed 's/#.*//' | awk '{print $1}' | tr -d ' "')

    # 提取端口
    local socks5_port=$(grep -A 2 "name: socks5-service" "$CONFIG_FILE" | grep "addr:" | head -1 | awk -F':' '{print $NF}' | tr -d ' ')

    echo -e "【Shadowsocks 配置】"
    echo -e "  端口: ${GREEN}${ss_port}${NC}"
    echo -e "  加密方式: ${GREEN}${ss_method}${NC}"
    echo -e "  密码: ${GREEN}${ss_password}${NC}"
    echo ""
    echo -e "【SOCKS5 配置】"
    echo -e "  端口: ${GREEN}${socks5_port}${NC}"
    echo -e "  用户名: ${GREEN}${socks5_user}${NC}"
    echo -e "  密码: ${GREEN}${socks5_password}${NC}"
    echo -e "${GREEN}=========================================${NC}"
}

# 4. 生成 Systemd 服务文件
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"

echo -e "正在创建服务文件: $SERVICE_FILE ..."

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Gost V3 Proxy Service
After=network.target

[Service]
Type=simple
# 关键：设置工作目录，确保能读取到 config.yaml
WorkingDirectory=${WORK_DIR}
ExecStart=${GOST_BIN} -C config.yaml
# 崩溃自动重启配置
Restart=always
RestartSec=3
# 建议增加文件描述符限制，防止连接数过多报错
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

# 5. 启动服务
echo -e "正在加载并启动服务..."
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

# 6. 检查状态
sleep 2
if systemctl is-active --quiet "$SERVICE_NAME"; then
    echo -e "${GREEN}=========================================${NC}"
    echo -e "${GREEN} 安装成功！Gost 已在后台运行并设置开机自启。${NC}"
    echo -e "${GREEN}=========================================${NC}"
    # 如果已成功启动，重复展示账号密码（便于确认）
    parse_and_show_creds
    echo -e "查看运行状态: systemctl status $SERVICE_NAME"
    echo -e "查看实时日志: journalctl -u $SERVICE_NAME -f"
else
    echo -e "${RED} 安装完成但启动失败。请查看日志排查原因：${NC}"
    journalctl -u "$SERVICE_NAME" --no-pager -n 10
fi